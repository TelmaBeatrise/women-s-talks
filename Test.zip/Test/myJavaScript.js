/* source https://www.w3schools.com */
/* top navigation */
 $(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").toggle();
    });
});
/* source http://www.jquerybyexample.net/2011/09/change-cursor-to-hand-on-mouseover-in.html */
$(document).ready(function() {
  $("#flip").hover(function() {
     $(this).css("cursor", "pointer");
  });
});
/* finish top navigation */
/* side navigation */
 $(document).ready(function(){/* side navigation opens */
    $("#dots").click(function(){
        $("#snavSm").animate({
            width: 'toggle'
        });
        $("#overlay2").toggle();/* overlay bacground */
        $("#addBtn").toggle();

    });
});
 $(document).ready(function() {
  $("#dots").hover(function() {
     $(this).css("cursor", "pointer");
  });
});
 $(document).ready(function(){/* side navigation close */
    $("#closed").click(function(){
      $("#snavSm").hide();
      $("#overlay2").toggle();
      $("#addBtn").toggle();
    });
});
/* stop side navigation */
/* toggle heart */
$(document).ready(function(){
    $("#toogleHeart").click(function(){
        $("#toogleHeart").toggleClass("toogleHeart");
    });
});

$(document).ready(function() {
  $(".responsiveButton").hover(function() {
     $(this).css("cursor", "pointer");
  });
});
/* stop toggle heart */
/* ______Add new post_________________
__________________________________*/
$(document).ready(function(){
    $("#addBtn").click(function(){
        $("#storyForm").toggle();
    });
    
});
$(document).ready(function(){
	$("#addBtn").click(function(){
        $("#overlay2").toggle();
    });
});

$(document).ready(function() {
  $("#addBtn").hover(function() {
     $(this).css("cursor", "pointer");
  });
});
/*creat new card */
 $(document).ready(function(){
	$("#storySubmit").click(function(){
		var imgCh = $("<img>").attr("src", "images/womenPortrait1.png").addClass("col-1 col-m-2 col-s-1 responsiveImg roundedImg");
		var h2Title = $("<h2></h2>").text($("#tS").val()).addClass("col-11  col-m-10 col-s-11 descriptionTitle");
		var pStory = $("<p></p>").text($("#sS").val()).addClass("col-11 col-m-10 col-s-12 descriptionBody");
		var divF = $("<div></div>").addClass("col-m-3 col-9 col-s-3");
		var heart = $("<button>&#10084;</button>").addClass("col-1 col-m-3 col-s-3 responsiveButton ");
		var comment = $("<button>&#x1f4ac;</button>").addClass("col-1 col-m-3 col-s-3 responsiveButton");
		var facebook = $("<button></button>").attr("href", "#").addClass("col-1 col-m-3 col-s-3 responsiveButton fa fa-facebook");

		var divIcons = $("<div></div>").append(divF, heart, comment, facebook).addClass("row col-m-12 col-12 col-s-12 descrIcons");
		var divCh = $("<div></div>").append(imgCh, h2Title, pStory, divIcons).addClass("row col-m-12 col-12 col-s-12 probleDescriptionCard shadow");

    	$("#testDiv").append(divCh);
    	$("#overlay2").toggle();
    	$("#storyForm").toggle();
    	
    });
});
/*_____finish new card____________
__________________________________*/
/*_____add comment____________
__________________________________*/
$(document).ready(function(){
	$("#comm").click(function(){
		$("#commentCard").toggle();
		$("#comm").toggleClass("active");
		$("#addBtn").toggle();
    });
});

 $(document).ready(function(){
	$("#commentSubmit").click(function(){
		var imgCom = $("<img>").attr("src", "images/womenPortrait1.png").addClass("col-1 col-m-2 responsiveImg roundedImg smallImg");
		var pDate = $("<p></p>").text("7.januar 2018 15:30").addClass("col-11 col-m-10 descriptionBody");
		var pCom = $("<p></p>").text($("#comSt").val()).addClass("col-11 col-m-10 descriptionBody");
		
		var divCommet = $("<div></div>").append(imgCom, pDate, pCom).addClass("row col-m-12 col-12 commCard ")
    	$("#commSt").prepend(divCommet);

    });
});

 /*_____finish add comment____________
__________________________________*/